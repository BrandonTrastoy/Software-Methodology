package com.example.bmi_calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

/**
 * @author: Brandon Trastoy
 * @author: Kyle VanWageninge
 *
 * This is the MainActivity class, it handles the activity_main.xml and
 * makes sure that all buttons perform their funtions with error checking.
 */
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final RadioButton americanSystem = (RadioButton) findViewById(R.id.americanSystem);
        final RadioButton metricSystem = (RadioButton) findViewById(R.id.metricSystem);

        Button calculateBMI = (Button) findViewById(R.id.calculateBMI);
        Button advice = (Button) findViewById(R.id.advice);

        /**
         * This method handles the onclick of the Calculate BMI button.
         * When pushed it makes sure that all EditText fields have value,
         * then calculates. If there is no values, then it displays an error.
         */
        calculateBMI.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                EditText weight = (EditText) findViewById(R.id.weight);
                EditText height = (EditText) findViewById(R.id.height);
                TextView output = (TextView) findViewById(R.id.output);

                if(!isEmpty()) {

                    double num1 = Double.parseDouble(weight.getText().toString());
                    double num2 = Double.parseDouble(height.getText().toString());

                    double result = 0;

                    if (americanSystem.isChecked()) {
                        result = ((num1 * 703) / (num2 * num2)) * 100;
                        result = Math.round(result);
                        result = result / 100;
                    } else if (metricSystem.isChecked()) {
                        result = (num1 / (num2 * num2)) * 100;
                        result = Math.round(result);
                        result = result / 100;
                    } else {
                        // Should not reach here
                        result = -1;
                    }
                    output.setText(result + "");
                }
            }
        });

        /**
         * This method handles the onclick of the Get Advice button.
         * When pushed it checks that the EditText fields have values,
         * then checks that the BMI has been calculated, then passes
         * the BMI to the next activity for it to be used.
         */
        advice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!isEmpty()) {

                    TextView output = (TextView) findViewById(R.id.output);

                    if(output.getText().toString().matches("")) {
                        output.setError("Please calculate your BMI first.");
                    }
                    else {
                        Intent getAdvice = new Intent(MainActivity.this, AdviceActivity.class);
                        getAdvice.putExtra("currentBMI", output.getText().toString());
                        startActivity(getAdvice);
                    }
                }
            }
        });
    }

    /**
     * This method checks when a radiobutton is clicked
     * and changes the hints based on the radiobutton.
     *
     * @param v
     */
    public void onRadioButtonClicked(View v)
    {
        EditText weight = (EditText) findViewById(R.id.weight);
        EditText height = (EditText) findViewById(R.id.height);

        boolean  checked = ((RadioButton) v).isChecked();

        switch(v.getId()){

            case R.id.americanSystem:
                if(checked) {
                    weight.setHint("Enter weight in pounds.");
                    height.setHint("Enter height in inches.");
                }
                break;

            case R.id.metricSystem:
                if(checked) {
                    weight.setHint("Enter weight in kilograms.");
                    height.setHint("Enter height in meters.");
                }
                break;
        }
    }

    /**
     * This method checks if the EditText fields are empty.
     * If empty, show errors and return true, else false.
     *
     * @return boolean
     */
    public boolean isEmpty() {

        EditText weight = (EditText) findViewById(R.id.weight);
        EditText height = (EditText) findViewById(R.id.height);

        if(weight.getText().toString().matches("") ||
                height.getText().toString().matches(""))
        {
            if(weight.getText().toString().matches("")) {
                weight.setError("Error: Enter Value For Weight");
            }
            if(height.getText().toString().matches("")) {
                height.setError("Error: Enter Value For Height");
            }
            return true;
        }

        else
            return false;
    }
}
