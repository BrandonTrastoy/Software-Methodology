package com.example.bmi_calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * @author: Brandon Trastoy
 * @author: Kyle VanWageninge
 *
 * This is the AdviceActivity class, it handles the activity_advice.xml and
 * makes sure that all buttons perform their funtions.
 */
public class AdviceActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_advice);

        this.setTitle("Advice");

        Button goBack = (Button) findViewById(R.id.goBack);

        Bundle bundle = getIntent().getExtras();
        Double bmi = Double.parseDouble(bundle.getString("currentBMI"));

        customMessage(bmi);

        /**
         * Handles the onclick of the Go Back button, changes the current
         * activity to the MainActivity
         */
        goBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(AdviceActivity.this, MainActivity.class));
            }
        });
    }

    /**
     * Displays custom messages based on BMI value
     *
     * @param bmi Body Mass Index, Doubles
     */
    void customMessage(Double bmi) {

        ImageView adviceImage = (ImageView) findViewById(R.id.imageHolder);
        TextView adviceMessage = (TextView) findViewById(R.id.adviceMessage);

        if(bmi < 18.5) {
            adviceImage.setImageResource(R.drawable.underweight);
            adviceMessage.setText("Underweight");
        } else if (bmi < 24.9) {
            adviceImage.setImageResource(R.drawable.normal);
            adviceMessage.setText("Normal");
        } else if (bmi < 29.9) {
            adviceImage.setImageResource(R.drawable.overweight);
            adviceMessage.setText("Overweight");
        } else {
            adviceImage.setImageResource(R.drawable.obese);
            adviceMessage.setText("Obese");
        }
    }
}
